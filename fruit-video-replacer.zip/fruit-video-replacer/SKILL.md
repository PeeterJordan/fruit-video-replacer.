---
name: fruit-video-replacer
description: Replaces people in a reference video with realistic 3D anthropomorphic fruit characters, using supplied character and background images while preserving the original audio, timing, actions, and scene order where the video tool supports it.
---

# Fruit Video Replacer

## Goal
Guide a video-editing workflow that replaces human characters with realistic 3D anthropomorphic fruit characters while retaining the structure of the source video.

## Inputs
The user may provide:
- The original TikTok video.
- Reference images for each fruit character.
- Background or scene images.
- A separate audio file, if the original audio is not embedded in the video.

## Requirements
1. Preserve the original dialogue, music, sound effects, pauses, and audio timing.
2. Preserve the source video's duration, scene order, cuts, and pacing.
3. Match each original person to the appropriate fruit character supplied by the user.
4. Treat supplied character images as the primary visual references.
5. Maintain consistent character identity across frames: fruit shape, face, colors, clothing, and proportions.
6. Replace the background with the supplied scene image when requested, matching perspective, scale, and lighting.
7. Recreate the original actions, gestures, positions, and movement as closely as the tool allows.
8. Integrate characters into the scene with coherent lighting, shadows, and occlusion.
9. Avoid blur, flicker, morphing, extra limbs, duplicate characters, and inconsistent appearance between frames.
10. Do not add captions, text, music, or effects that are not in the source.
11. Do not invent scenes or change dialogue.
12. Keep the original framing and aspect ratio, especially vertical 9:16 when applicable.

## Workflow
1. Inspect the source video and identify its characters, cuts, actions, duration, and framing.
2. Map each person to a user-provided fruit character.
3. Identify the background areas to replace.
4. Plan the transformation scene by scene while maintaining visual continuity.
5. Use a video-editing or video-generation tool that supports video input and visual references.
6. If the tool cannot process the entire video, split it into short segments and reuse consistent character references.
7. Reassemble segments in their original order.
8. Restore the original audio without changing its timing.
9. Review for flicker, blur, identity drift, compositing errors, and synchronization issues.
10. Export at the source video's aspect ratio and, where possible, its resolution and frame rate.

## Limitations
This skill provides instructions and workflow guidance; it does not itself render or edit video. Do not claim the transformation has been completed unless a capable video tool actually produced the result. If the available tool cannot replace characters in video, explain the limitation and suggest a compatible workflow.

## Assistant behavior
If required files are missing, ask only for the files needed to proceed. Be explicit about tool limitations and preserve the original audio and synchronization whenever technically possible.
